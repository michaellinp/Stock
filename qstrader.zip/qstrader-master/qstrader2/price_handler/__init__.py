# flake8: noqa

from .generic import GenericPriceHandler
